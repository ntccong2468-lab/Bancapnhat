﻿CÀI WINDOWS-MCP CHO VN CODE

1. Giải nén toàn bộ thư mục này trên máy Windows đang cài VN Code.
2. Bấm đúp Install-WindowsMCP.cmd, chờ thông báo cài xong.
3. Bấm đúp Start-WindowsMCP.cmd và giữ cửa sổ đó mở.

Chạy bằng tài khoản Windows bình thường, không cần Run as administrator.
Công cụ chưa tự nối máy Windows với Codex cloud: cần endpoint HTTPS/tunnel/VPN tới worker.
Server cục bộ: http://127.0.0.1:18765/mcp (có xác thực).
Không gửi token trong chat. Khi đã có endpoint, dùng Export-ConnectionToken.cmd rồi dán vào Secrets môi trường Codex tên VNCODE_WINDOWS_MCP_TOKEN, đúng hostname.

Hướng dẫn đầy đủ: tools/windows-mcp/README.md trong repo VN Code.
Nguồn Windows-MCP pin59e3b194799d5a1ced14298bca4cd200f7edbfd8; không sửa dữ liệu app hoặc tạo service/firewall/tunnel.
